const express = require('express');
const bodyParser = require('body-parser');
const shortid = require('shortid');
const morgan = require('morgan');
const app = express();
const PORT = 5000;

let urlDatabase = {};

app.use(morgan('combined'));
app.use(bodyParser.json());

function isValidURL(url) {
  try {
    new URL(url);
    return true;
  } catch {
    return false;
  }
}

app.post('/shorturls', (req, res) => {
  const { url, validity = 30, shortcode } = req.body;
  if (!isValidURL(url)) return res.status(400).json({ error: 'Invalid URL format' });

  const code = shortcode || shortid.generate();
  if (!/^[a-zA-Z0-9]+$/.test(code)) return res.status(400).json({ error: 'Invalid shortcode' });

  const now = new Date();
  const expiry = new Date(now.getTime() + validity * 60000);
  urlDatabase[code] = { url, expiry, createdAt: now, clicks: [] };

  res.status(201).json({ shortLink: `http://localhost:5000/${code}`, expiry: expiry.toISOString() });
});

app.get('/shorturls/:code', (req, res) => {
  const code = req.params.code;
  const entry = urlDatabase[code];
  if (!entry) return res.status(404).json({ error: 'Shortcode not found' });

  res.json({
    url: entry.url,
    createdAt: entry.createdAt,
    expiry: entry.expiry,
    clicks: entry.clicks.length,
    detailedClicks: entry.clicks
  });
});

app.get('/:code', (req, res) => {
  const code = req.params.code;
  const entry = urlDatabase[code];
  if (!entry || new Date() > new Date(entry.expiry)) return res.status(404).send('Shortlink expired or not found');

  entry.clicks.push({
    timestamp: new Date(),
    referrer: req.get('Referrer') || 'unknown',
    location: 'India'
  });

  res.redirect(entry.url);
});

app.listen(PORT, () => console.log(`Server running on port ${PORT}`));