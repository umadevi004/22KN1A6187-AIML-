import React, { useState } from 'react';
import axios from 'axios';
import { Container, TextField, Button, Typography, List, ListItem } from '@mui/material';

function App() {
  const [urls, setUrls] = useState(['']);
  const [results, setResults] = useState([]);

  const handleChange = (index, value) => {
    const newUrls = [...urls];
    newUrls[index] = value;
    setUrls(newUrls);
  };

  const handleAddUrl = () => {
    if (urls.length < 5) setUrls([...urls, '']);
  };

  const handleShorten = async () => {
    const promises = urls.map(u => axios.post('http://localhost:5000/shorturls', {
      url: u,
      validity: 30
    }));
    const res = await Promise.all(promises);
    setResults(res.map(r => r.data));
  };

  return (
    <Container>
      <Typography variant="h4" gutterBottom>URL Shortener</Typography>
      {urls.map((url, index) => (
        <TextField
          key={index}
          value={url}
          onChange={(e) => handleChange(index, e.target.value)}
          label={`URL ${index + 1}`}
          fullWidth
          margin="normal"
        />
      ))}
      <Button onClick={handleAddUrl} variant="outlined" disabled={urls.length >= 5}>Add More</Button>
      <Button onClick={handleShorten} variant="contained" color="primary">Shorten</Button>
      <List>
        {results.map((r, idx) => (
          <ListItem key={idx}>
            <Typography variant="body1">
              Short: <a href={r.shortLink}>{r.shortLink}</a> | Expires: {r.expiry}
            </Typography>
          </ListItem>
        ))}
      </List>
    </Container>
  );
}

export default App;